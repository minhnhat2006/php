=== Gateway Child Theme ===
Contributors: rescuethemes
Tags: first, second, third
Requires at least: 4.0
Tested up to: 4.2.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This child theme is for the Gateway WordPress Theme by Rescue Themes. The parent theme is available at:

https://rescuethemes.com/wordpress-themes/gateway/

== Installation ==

1. Install the parent theme, Gateway
2. Install this child theme and activate it.
3. Continue with your theme setup and customization. 

== Changelog ==

= 1.0 =
* Initial Release