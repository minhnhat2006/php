For instructions on how to install the demo content, please see:

http://docs.rescuethemes.com/article/43-gateway-demo-content