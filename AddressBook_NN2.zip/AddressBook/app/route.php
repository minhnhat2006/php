<?php

define ('DEFAULT_CONTROLLER', 'EntryController');
define ('DEFAULT_ACTION', 'ListAction');

include 'route.core.php';